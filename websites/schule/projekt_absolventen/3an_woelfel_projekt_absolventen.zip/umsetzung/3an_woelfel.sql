-- phpMyAdmin SQL Dump
-- version 3.0.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 15. Juli 2009 um 13:51
-- Server Version: 5.0.45
-- PHP-Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `3an_woelfel`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `id` int(5) NOT NULL auto_increment,
  `titel` varchar(30) NOT NULL,
  `head` text NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY  (`id`,`titel`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Daten für Tabelle `content`
--

INSERT INTO `content` (`id`, `titel`, `head`, `content`) VALUES
(1, 'news', '<link rel="alternate" type="application/rss+xml" title="RSS-Newsfeed" href="feed.php" />', '<!--\r\n	Copyright 2008 Philip W&ouml;lfel <philip.woelfel@frig.at>\r\n-->\r\n<h1>News</h1>\r\n<?php\r\n	//$selbst = "?site=" .$_GET[''site''];\r\n	global $selbst;\r\n	global $loggedin;\r\n	\r\n	if(isset($_GET[''id''])){\r\n		$daten = mysql_query("select titel, datum, text, id from news where id = " .$_GET[''id''] ." order by id desc");\r\n		\r\n		if($eintr = mysql_fetch_array($daten)){\r\n			echo ''<h2 class="news">'' .$eintr[''titel''] .''</h2>\r\n					<b>vom '' . date("d.m.Y \\u\\m H:i:s", strtotime($eintr[''datum''])) .''</b><br /><br />''\r\n					.$eintr[''text'']\r\n					.''<br /><hr /><br />'';\r\n			\r\n			if($loggedin){\r\n				if(isset($_POST[''comment''])){\r\n					$sql = "insert into news_comments(newsid, userid, comment) values(''" .$_GET[''id''] ."'', ''" .$_SESSION[''userid''] ."'', ''" .mysql_real_escape_string(htmlspecialchars($_POST[''comment''])) ."'')";\r\n					if(!mysql_query($sql)){\r\n						echo mysql_error();\r\n					}\r\n				}\r\n				echo ''<h2 class="news">Kommentare</h2>'';\r\n				$comments = mysql_query("select nc.datum, nc.comment, u.vorname, u.nachname from news_comments nc, users u where nc.newsid=" .$_GET[''id''] ." and nc.userid = u.id order by datum asc");\r\n				while($com=mysql_fetch_array($comments)){\r\n					echo ''<b>'' .$com[''vorname''] .'' '' .$com[''nachname''] .'', '' .date("d.m.Y \\u\\m H:i:s", strtotime($com[''datum''])) .''</b><br />'' .$com[''comment''] .''<br />--------------------------------------------<br />'';\r\n				}\r\n				\r\n				echo ''<br /><br /><form method="post" action="'' .$selbst .''&amp;id='' .$_GET[''id''] .''">\r\n					Dein Kommentar:<br />\r\n					<textarea name="comment" rows="10" cols="50"></textarea><br />\r\n					<input type="submit" value="absenden" />\r\n					</form>'';\r\n			}\r\n		}\r\n		else{\r\n			echo ''Dieser Newsartikel existiert nicht!'';\r\n		}\r\n	}\r\n	else{\r\n		$daten = mysql_query("select titel, datum, text, id from news order by id desc");\r\n		while($row = mysql_fetch_array($daten)){\r\n			echo ''<h2 class="news"><a href="'' .$selbst .''&amp;id='' .$row[''id''] .''">'' .$row[''titel''] .''</a></h2>\r\n					<b>vom '' . date("d.m.Y \\u\\m H:i", strtotime($row[''datum''])) .''</b><br /><br />''\r\n					.$row[''text'']\r\n					.''<br /><hr /><br />'';\r\n		}\r\n	}\r\n?>'),
(2, 'kalender', '', '<!--\r\n	Copyright 2008 Philip W&ouml;lfel <philip.woelfel@frig.at>\r\n-->\r\n<?php\r\n	$monate[1]=''J&auml;nner'';\r\n	$monate[2]=''Februar'';\r\n	$monate[3]=''M&auml;rz'';\r\n	$monate[4]=''April'';\r\n	$monate[5]=''Mai'';\r\n	$monate[6]=''Juni'';\r\n	$monate[7]=''Juli'';\r\n	$monate[8]=''August'';\r\n	$monate[9]=''September'';\r\n	$monate[10]=''Oktober'';\r\n	$monate[11]=''November'';\r\n	$monate[12]=''Dezember'';\r\n	$jahr = date("Y");\n	//$selbst = "?site=" .$_GET[''site''];\r\n	global $selbst;\r\n	if(isset($_GET[''month''])){\r\n		$month = $_GET[''month''];\r\n		\r\n		if($month==1 || $month==3 || $month==5 || $month==7 || $month==8 || $month==10 || $month==12){\r\n			$days = 31; \r\n		}\r\n		else{\r\n			if($month==4 || $month==6 || $month==9 || $month==11){\r\n				$days = 30;\r\n			}\r\n			else{\r\n				$days = 28;\r\n			}\r\n		}\r\n		$body =	''<table border="1" align="center">\r\n				<tr>\r\n				<td colspan="2" align="center" class="noborder"><a href="'' .$selbst .''&amp;month='' .($month-1) .''">'' .$monate[$month-1] .''</a></td>\r\n				<td colspan="3" align="center" class="noborder">'' .$monate[$month] .''</td>\r\n				<td colspan="2" align="center" class="noborder"><a href="'' .$selbst .''&amp;month='' .($month+1) .''">'' .$monate[$month+1] .''</a></td>\r\n				</tr>\r\n				<tr>\r\n				<td align="center" class="noborder">Montag</td>\r\n				<td align="center" class="noborder">Dienstag</td>\r\n				<td align="center" class="noborder">Mittwoch</td>\r\n				<td align="center" class="noborder">Donnerstag</td>\r\n				<td align="center" class="noborder">Freitag</td>\r\n				<td align="center" class="noborder">Samstag</td>\r\n				<td align="center" class="noborder">Sonntag</td>\r\n				</tr>\r\n				<tr>'';\r\n				\r\n				//verschiebung f&uuml;r wochentage\n				/*\r\n				$weekday = jddayofweek ( cal_to_jd(CAL_GREGORIAN, $month, 1, $jahr) , 0 );\r\n				switch ($weekday){\r\n					case 1: $vers=0; break;//Montag\r\n					case 2: $vers=1; break;//Dienstag\r\n					case 3: $vers=2; break;//Mittwoch\r\n					case 4: $vers=3; break;//Donnerstag\r\n					case 5: $vers=4; break;//Freitag\r\n					case 6: $vers=5; break;//Samstag\r\n					case 0: $vers=6; break;//Sonntag\r\n				}\r\n				*/\n				$vers = date("N")-1;\r\n				$tds=0;\r\n				\r\n				for($k=0;$k<$vers;$k++){\r\n					$body .= ''<td class="noborder"> </td>'';\r\n					$tds++;\r\n				}\r\n				\r\n		$dates = mysql_query("select id, datum, kurztext, langtext, DATE_FORMAT(datum,''%e'') as tag,DATE_FORMAT(datum,''%c'') as monat, DATE_FORMAT(datum,''%Y'') as jahr from termine where DATE_FORMAT(datum,''%Y'')=" .$jahr ." and  DATE_FORMAT(datum,''%c'')=" .$month ." order by datum asc");\r\n		$j=0;\r\n		$termin = mysql_fetch_array($dates);\r\n		for($i=1;$i<=$days;$i++){\r\n			$body .= ''<td width="100" height="100" align="left" valign="top">'' .$i .''<br />'';\r\n			$tds++;\r\n			if($termin[''tag'']==$i){\r\n				$body .= ''<a href="'' .$selbst .''&amp;tid='' .$termin[''id''] .''">'' .$termin[''kurztext''] .''</a>'';\r\n				$termin = mysql_fetch_array($dates);\r\n			}\r\n			$body .= ''</td>'';\r\n			if($tds%7==0 && $tds/7<5){\r\n				$body .= ''</tr>\r\n				<tr>\r\n				'';\r\n			}\r\n		}\r\n		$body .= ''</tr>\r\n		<tr>\r\n		<td colspan="7" align="center" class="noborder"><a href="'' .$selbst .''">zur&uuml;ck</a></td>\r\n		</tr>\r\n		</table>'';\r\n	}\r\n	elseif(isset($_GET[''new''])){\r\n		$body .= ''<form method="post" action="'' .$selbst .''&amp;new=true">\r\nJahr: <select name="jahr">\r\n				<option value="'' .$jahr .''">'' .$jahr .''</option>\r\n				<option value="'' .($jahr+1) .''">'' .($jahr+1) .''</option>\r\n				<option value="'' .($jahr+2) .''">'' .($jahr+2) .''</option>\r\n				<option value="'' .($jahr+3) .''">'' .($jahr+3) .''</option>\r\n			</select><br />\r\n\r\n		Monat: <select name="monat">\r\n		'';\r\n		for($i=1;$i<=12;$i++){\r\n			$body .= ''<option value="'' .$i .''">'' .$monate[$i] .''</option>\r\n			'';\r\n		}\r\n		$body .= 	''</select>\r\n					<br />\r\n					Tag: <select name="tag">\r\n					'';\r\n		for($j=1;$j<=31;$j++){\r\n			$body .= ''<option value="'' .$j .''">'' .$j .''</option>\r\n			'';\r\n		}\r\n		$body .= ''</select>\r\n		<br />\r\n		Termin: <input type="text" name="termin" />\r\n		<br />\r\n		<input type="submit" value="Termin speichern" />\r\n		</form>\r\n		<br />\r\n		<a href="'' .$selbst .''">zur&uuml;ck</a>'';\r\n		\r\n		if(isset($_POST[''monat'']) && isset($_POST[''tag'']) && isset($_POST[''termin'']) && isset($_POST[''jahr''])){\r\n			$monat = $_POST[''monat''];\r\n			$tag = $_POST[''tag''];\r\n			$termin = $_POST[''termin''];\r\n			$jahr = $_POST[''jahr''];\r\n			mysql_query("insert into termine (`datum`,`kurztext`,`langtext`) values (''" .$jahr ."-" .$monat ."-" .$tag ."'', ''" .$termin ."'', ''lang'')");\r\n		}\r\n	}\r\n	elseif(isset($_GET[''tid''])){\r\n		$termin_qry = mysql_query("select * from termine where id=" .$_GET[''tid'']);\r\n		$termin = mysql_fetch_array($termin_qry);\r\n		\r\n		echo ''<h2>'' .$termin[''kurztext''] .''</h2>'';\r\n		echo ''am '' .date("d.m.Y", strtotime($termin[''datum''])) .''<br /><br />'';\r\n		echo $termin[''langtext''];\r\n	}\r\n	else{\r\n		$body=	''Bitte Monat ausw&auml;hlen!<br />\r\n				<a href="'' .$selbst .''&amp;month=1">J&auml;nner</a> <a href="'' .$selbst .''&amp;month=2">Februar</a> <a href="'' .$selbst .''&amp;month=3">M&auml;rz</a> <a href="'' .$selbst .''&amp;month=4">April</a> <a href="'' .$selbst .''&amp;month=5">Mai</a> <a href="'' .$selbst .''&amp;month=6">Juni</a> <a href="'' .$selbst .''&amp;month=7">Juli</a> <a href="'' .$selbst .''&amp;month=8">August</a> <a href="'' .$selbst .''&amp;month=9">September</a> <a href="'' .$selbst .''&amp;month=10">Oktober</a> <a href="'' .$selbst .''&amp;month=11">November</a> <a href="'' .$selbst .''&amp;month=12">Dezember</a><br /><a href="'' .$selbst .''&amp;new=true">neuer Eintrag</a>'';\r\n	}\r\n	\r\n	\r\n	\r\n	echo $body;\r\n		\r\n?>'),
(3, 'shoutbox', '<script type="text/javascript">\r\nfunction addImage(name){\r\n	document.getElementById(''text'').value+=name +'' '';\r\n}\r\n</script>', '<!--\r\n	Copyright 2008 Philip W&ouml;lfel <philip.woelfel@frig.at>\r\n-->\r\n\r\n<?php\r\n	if(isset($_POST[''name'']) && isset($_POST[''text''])){\r\n		$name=$_POST[''name''];\r\n		$text=$_POST[''text''];\r\n		mysql_query("INSERT INTO shoutbox (Name, Nachricht) VALUES (''" .$name ."'', ''" .$text ."'')");\r\n	}\r\n	\r\n\r\n\r\n	\r\n	echo ''<form action="" method="post">\r\n		<table border="0">\r\n		<tr>\r\n				<td colspan="7"><input type="text" id="name" name="name" value="Name" onfocus="if(this.value==\\''Name\\''){this.value=\\''\\''}" /></td>\r\n		</tr>\r\n		<tr>\r\n				<td colspan="7"><input type="text" name="text" id="text" value="Text" onfocus="if(this.value==\\''Text\\''){this.value=\\''\\''}" /></td>\r\n		</tr>\r\n		<tr>\r\n				<td colspan="7" align="center"><input type="submit" value=":: senden ::" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td align="center"><a href="javascript:addImage(\\'':D\\'')"><img src="images/smileys/biggrin.gif" alt="biggrin" border="0" /></a></td>\r\n			<td align="center"><a href="javascript:addImage(\\'':P\\'')"><img src="images/smileys/tongue.gif" alt="tongue" border="0" /></a></td>\r\n			<td align="center"><a href="javascript:addImage(\\'':)\\'')"><img src="images/smileys/smile.gif" alt="smile" border="0" /></a></td>\r\n			<td align="center"><a href="javascript:addImage(\\'':(\\'')"><img src="images/smileys/frown.gif" alt="frown" border="0" /></a></td>\r\n			<td align="center"><a href="javascript:addImage(\\'';(\\'')"><img src="images/smileys/cry.gif" alt="cry" border="0" /></a></td>\r\n			<td align="center"><a href="javascript:addImage(\\'';|\\'')"><img src="images/smileys/mad.gif" alt="mad" border="0" /></a></td>\r\n			<td align="center"><a href="javascript:addImage(\\'';D\\'')"><img src="images/smileys/diablotin.gif" alt="biggrin" border="0" /></a></td>\r\n		</tr>\r\n		</table></form>'';\r\n		$replace = array(":D", ":P", ":)", ":(", ";(", ";|", ";D");\r\n		$repl = array("biggrin.gif", "tongue.gif", "smile.gif", "frown.gif", "cry.gif", "mad.gif", "diablotin.gif");\r\n		$temp="";\r\n		//SELECT s.Nachricht as Nachricht, l.Name as Name, s.personID as personID FROM shoutbox s,login_daten l WHERE s.personID=l.personID ORDER BY created DESC\r\n		$daten = mysql_query("SELECT Nachricht, Name, id FROM shoutbox ORDER BY created DESC");\r\n		\r\n		while($row = mysql_fetch_array($daten)){\r\n				$temp = $row[''Nachricht''];\r\n				for ($i = 0; $i < sizeof($replace); $i++){\r\n					$temp = str_replace($replace[$i], ''<img src="images/smileys/'' .$repl[$i] .''" alt="'' .$repl[$i] .''" />'', $temp);\r\n				}				\r\n				echo ''<b>'' .$row[''Name''] .'':</b> '' . $temp .''<br />-----------------------<br />'';\r\n		}\r\n		\r\n		?>'),
(4, 'termine', '', '<!--\r\n	Copyright 2008 Philip W&ouml;lfel <philip.woelfel@frig.at>\r\n-->\r\n<?php	\r\n	$content =''<h2>Termine</h2>'';\r\n	\r\n	$termine = mysql_query("select id, datum, kurztext from termine where datum > CURDATE() order by datum asc") or die(mysql_error());\r\n	if(mysql_num_rows($termine)==0){\r\n		$content .= "keine Termine vorhanden";\r\n	}\r\n	else{\r\n		$content .=	''<ul type="square">'';\r\n		while($row = mysql_fetch_array($termine)){\r\n			$content .= ''<li>'' .$row[''datum''] .'': '' .$row[''kurztext''] .''</li>'';\r\n		}\r\n		$content .= ''</ul>'';\r\n	}\r\n	echo $content;\r\n?>\r\n\r\n'),
(5, 'test_login', '<style type="text/css">\r\n#yay{color: #00F;}\r\n</style>\r\n<script type="text/javascript">\r\nfunction showmsg(msg){\r\n  alert(msg);\r\n}\r\n</script>', '<!--\r\n	Copyright 2008 Philip W&ouml;lfel <philip.woelfel@frig.at>\r\n-->\r\n<p id="yay">Das ist eine Beispielseite die zeigen soll, dass man sich einloggen muss um diese Seite zu betrachten!</p>\r\nAu&szlig;erdem wird gezeigt das man auch CSS Code einbauen kann!\r\n<input type="button" value="und Javascript auch!" onclick="showmsg(''Yay es funktioniert :D'')" />'),
(6, 'register', '<script type="text/javascript">\r\nvar DEBUG = false; //Allerhand debugmessages ausgeben\r\nvar regexs = new Array(10); //Die Regexs mit denen die Felder ueberprueft werden\r\nregexs[''username''] = "^\\\\w{3,20}$";\r\nregexs[''passwort''] = "^\\\\w{6,20}$";\r\nregexs[''passwort_best''] = "^\\\\w{6,20}$";\r\nregexs[''vorname''] = "^[A-ZÜÄÖ]?[a-zöäüß]+(( |-)[A-ZÜÄÖ]?[a-zöäüß]+)*$";\r\nregexs[''nachname''] = "^[A-ZÜÄÖ]?[a-zöäü]+( [A-ZÜÄÖ]?[a-zöäü]+)*$";\r\nregexs[''email''] = "^([\\\\wüöäÄÖÜ]+(\\\\-|\\\\.))*([\\\\wöäüÖÄÜ]+)@([\\\\wöäüÖÄÜ]+\\\\.)+\\\\w{2,}$";\r\n\r\nvar errors = new Array(10);//Die Fehlermeldungen die ausgegeben werden\r\nerrors[''username''] = "Ung&uuml;ltiger Username! Der Username muss mindestens 3 Zeichen lang sein und darf maximal 20 Zeichen lang sein und nur a-z, A-Z, 0-9 und _ enthalten.";\r\nerrors[''passwort''] = "Fehler beim Passwort! Das Passwort muss mindestens 6 Zeichen lang sein und darf maximal 20 Zeichen lang sein und nur a-z, A-Z, 0-9 und _ enthalten.";\r\nerrors[''passwort_best''] = "Fehler bei der Passwort wiederholung! Das Passwort muss mindestens 6 Zeichen lang sein und darf maximal 20 Zeichen lang sein und nur a-z, A-Z, 0-9 und _ enthalten.";\r\nerrors[''vorname''] = "Ung&uuml;ltiger Vorname! Der Vorname darf nur a-z, A-Z, &auml;, &ouml;, &uuml;, &Auml;, &Ouml; und &Uuml; enthalten und nur der erste Buchstabe darf gro&szlig; sein.";\r\nerrors[''nachname''] = "Ung&uuml;ltiger Nachname! Der Nachname darf nur a-z, A-Z, &auml;, &ouml;, &uuml;, &Auml;, &Ouml; und &Uuml; enthalten und nur der erste Buchstabe darf gro&szlig; sein.";\r\nerrors[''email''] = "Ung&uuml;ltige E-Mail Adresse!";\r\n\r\nvar niceNames = new Array(10);\r\nniceNames[''username''] = "Username";\r\nniceNames[''passwort''] = "Passwort";\r\nniceNames[''passwort_best''] = "Passwort wiederholen";\r\nniceNames[''vorname''] = "Vorname";\r\nniceNames[''nachname''] = "Nachname";\r\nniceNames[''email''] = "E-Mail";\r\n\r\nvar checkFields = new Array(\r\n	"username",\r\n	"passwort",\r\n	"passwort_best",\r\n	"vorname",\r\n	"nachname",\r\n	"email"\r\n);\r\n\r\nvar checkDoubleFields = new Array(\r\n	new Array("passwort", "passwort_best")\r\n);\r\n\r\nfunction check(feld){\r\n	var f = document.getElementById(feld); //Das Feld das ueberprueft wird\r\n	var inh = f.value;\r\n	var rege = new RegExp(regexs[feld]); //Die Regex mit der ueberprueft wird\r\n	\r\n	if(inh==""){\r\n		document.getElementById(feld +"_errmsg").innerHTML="Feld " +niceNames[feld] +" nicht ausgef&uuml;llt!";\r\n		document.getElementById(feld).style.backgroundColor="#ef3a3b";\r\n		return false;\r\n	}\r\n	\r\n	debug("Regex: " +rege);\r\n	debug("Value: " +inh);\r\n	debug("Pos: " +inh.search(rege));\r\n	\r\n	\r\n	if(rege.test(inh)){\r\n		debug("test");\r\n		document.getElementById(feld +"_errmsg").innerHTML="";\r\n		document.getElementById(feld).style.backgroundColor="#fff";\r\n		return true;\r\n	}\r\n	else{\r\n		debug("nichttest");\r\n		document.getElementById(feld +"_errmsg").innerHTML=errors[feld];\r\n		document.getElementById(feld).style.backgroundColor="#ef3a3b";\r\n		return false;\r\n	}\r\n}\r\n\r\nfunction checkDouble(feld1, feld2){\r\n	if(check(feld1) && check(feld2)){\r\n		var f1 = document.getElementById(feld1);\r\n		var f2 = document.getElementById(feld2);\r\n		if(!(f1.value==f2.value)){\r\n			document.getElementById(feld1 +"_errmsg").innerHTML += "Das Feld " +niceNames[feld1] +" ist nicht gleich dem Feld " +niceNames[feld2];\r\n			document.getElementById(feld2 +"_errmsg").innerHTML += "Das Feld " +niceNames[feld2] +" ist nicht gleich dem Feld " +niceNames[feld1];\r\n		}\r\n		return true;\r\n	}\r\n	else{\r\n		return false;\r\n	}\r\n}\r\n\r\nfunction fullCheck(){\r\n	var erg = true;\r\n	for(var i=0;i<checkFields.length;i++){\r\n		if(!check(checkFields[i])){\r\n			erg = false;\r\n			debug("6, setzen(check, " +checkFields[i ]+")");\r\n		}\r\n	}\r\n	\r\n	for(var j=0;j<checkDoubleFields.length;j++){\r\n		if(!checkDouble(checkDoubleFields[j][0], checkDoubleFields[j][1])){\r\n			erg = false;\r\n			debug("6, setzen(doublecheck, " +checkDoubleFields[j][0] +", " +checkDoubleFields[j][1] +")");\r\n		}\r\n	}\r\n	\r\n	if(erg){\r\n		debug("bestanden");\r\n		document.useranmeldung.submit();\r\n		\r\n	}\r\n	return erg;\r\n}\r\n\r\nvar debugfenst = null;\r\nfunction debug(msg){\r\n	if(DEBUG){\r\n		if(debugfenst==null || debugfenst.closed){\r\n			debugfenst = window.open("about:blank", "debugFenster", "width=800, height=400, menubar=no, resizable=yes, scrollbars=yes");\r\n			debugfenst.document.open()\r\n			debugfenst.document.write(msg+"<br />");\r\n		}\r\n		else{\r\n			debugfenst.document.write(msg +"<br />");\r\n		}\r\n	}\r\n}\r\n</script>', '<!--\r\n	Copyright 2008 Philip Woelfel <philip@woelfel.at>\r\n-->\r\n<?php	\r\n	function myescape($str){\r\n		$replace[0][0]="ö";\r\n		$replace[0][1]="&ouml;";\r\n		$replace[1][0]="ä";\r\n		$replace[1][1]="&auml;";\r\n		$replace[2][0]="ü";\r\n		$replace[2][1]="&uuml;";\r\n		$replace[3][0]="Ö";\r\n		$replace[3][1]="&Ouml;";\r\n		$replace[4][0]="Ä";\r\n		$replace[4][1]="&Auml;";\r\n		$replace[5][0]="Ü";\r\n		$replace[5][1]="&Uuml;";\r\n		$replace[6][0]="ß";\r\n		$replace[6][1]="&szlig;";\r\n		//echo "funktion!";\r\n		//echo "<pre>" .print_r($replace,true) ."</pre>";\r\n		for($i=0;$i<sizeof($replace);$i++){\r\n			$str = str_replace($replace[$i][0], $replace[$i][1], $str);\r\n			//echo "0: {$replace[$i][0]} <br />1: {$replace[$i][1]}<br />";\r\n		}\r\n		return $str;\r\n	}\r\n	\r\n	if(isset($_POST[''username''], $_POST[''passwort''], $_POST[''vorname''], $_POST[''nachname''], $_POST[''email''])){\r\n		\r\n		$ins_qry = "INSERT INTO\r\n						users (name, passwort, rechte, vorname, nachname, email, reg_hash";\r\n		\r\n		if(isset($_POST[''ort'']) && $_POST[''ort'']!=""){\r\n			$ins_qry .= ", ort";\r\n		}\r\n		if(isset($_POST[''telnr'']) && $_POST[''telnr'']!=""){\r\n			$ins_qry .= ", telnr";\r\n		}\r\n		if(isset($_POST[''msn'']) && $_POST[''msn'']!=""){\r\n			$ins_qry .= ", msn";\r\n		}\r\n		if(isset($_POST[''icq'']) && $_POST[''icq'']!=""){\r\n			$ins_qry .= ", icq";\r\n		}\r\n		if(isset($_POST[''skype'']) && $_POST[''skype'']!=""){\r\n			$ins_qry .= ", skype";\r\n		}\r\n		\r\n		$ins_qry .= ") VALUES (''" .$_POST[''username''] ."'', ''" .hash($config[''hash_algo''], $_POST[''passwort'']) ."'', ''50'', ''" . myescape($_POST[''vorname'']) ."'', ''" . myescape($_POST[''nachname'']) ."'', ''" . $_POST[''email''] ."'', ''" .hash("whirlpool", microtime()) ."''";\r\n		\r\n		if(isset($_POST[''ort'']) && $_POST[''ort'']!=""){\r\n			$ins_qry .= ", ''".myescape($_POST[''ort'']) ."''";\r\n		}\r\n		if(isset($_POST[''telnr'']) && $_POST[''telnr'']!=""){\r\n			$ins_qry .= ", ''".myescape($_POST[''telnr'']) ."''";\r\n		}\r\n		if(isset($_POST[''msn'']) && $_POST[''msn'']!=""){\r\n			$ins_qry .= ", ''".myescape($_POST[''msn'']) ."''";\r\n		}\r\n		if(isset($_POST[''icq'']) && $_POST[''icq'']!=""){\r\n			$ins_qry .= ", ''".myescape($_POST[''icq'']) ."''";\r\n		}\r\n		if(isset($_POST[''skype'']) && $_POST[''skype'']!=""){\r\n			$ins_qry .= ", ''".myescape($_POST[''skype'']) ."''";\r\n		}\r\n		\r\n		$ins_qry .= ")";\r\n		\r\n		if(mysql_query($ins_qry)){\r\n			//echo $ins_qry."<br />";\r\n			$hash_sql = "select reg_hash, vorname, nachname, name from users where id = " .mysql_insert_id();\r\n			$hash_res = mysql_query($hash_sql);\r\n			$hash = mysql_fetch_array($hash_res);\r\n			\r\n			$msg = "Herzlich willkommen {$hash[''vorname'']} {$hash[''nachname'']}!\\n";\r\n			$msg .= "Danke fÃ¼r ihre Anmeldung auf der Absolventenseite der HTL3R.\\n\\n";\r\n			$msg .= "Ihr Benutzername lautet: {$hash[''name'']} \\n\\n";\r\n			$msg .= "Klicken sie bitte auf den folgenden Link um ihren Benutzer freizuschalten: ";\r\n			$msg .= dirname($_SERVER[''HTTP_REFERER'']) ."/unlock_user.php?unlock={$hash[''reg_hash'']}";\r\n			//echo $msg;\r\n			\r\n			mail($_POST[''email''], "Registrierung auf der HTL3Rennweg Absolventenseite", $msg);\r\n			echo ''Danke f&uuml;r die Registrierung! <a href="index.php">Hier</a> kommen sie zur Hauptseite!'';\r\n		}\r\n		else{\r\n			echo mysql_error() ."<br />";// .$ins_qry ."<br />";\r\n			echo "Fehler bei der Registrierung, bitte versuchen sie es erneut!";\r\n		}\r\n		\r\n	}\r\n	\r\n	else{\r\n		echo ''<h1>Registrierung</h1>\r\n		<form method="post" action="" name="useranmeldung">\r\n			<table>\r\n				<tr>\r\n					<td>*Benutzername:</td>\r\n					<td><input type="text" name="username" id="username" onblur="check(\\''username\\'')"  maxlength="20" /></td>\r\n					<td><div id="username_errmsg"></div></td>\r\n				</tr>\r\n				<tr>\r\n					<td>*Passwort:</td>\r\n					<td><input type="password" name="passwort" id="passwort" onblur="check(\\''passwort\\'');checkDouble(\\''passwort\\'', \\''passwort_best\\'')" maxlength="20" /></td>\r\n					<td><div id="passwort_errmsg"></div></td>\r\n				</tr>\r\n				<tr>\r\n					<td>*Passwort wiederholen:</td>\r\n					<td><input type="password" name="passwort_best" id="passwort_best" onblur="check(\\''passwort_best\\'');checkDouble(\\''passwort\\'', \\''passwort_best\\'')"  maxlength="20" /></td>\r\n					<td><div id="passwort_best_errmsg"></div></td>\r\n				</tr>\r\n				<tr>\r\n					<td>*Vorname:</td>\r\n					<td><input type="text" name="vorname" id="vorname" onblur="check(\\''vorname\\'')" /></td>\r\n					<td><div id="vorname_errmsg"></div></td>\r\n				</tr>\r\n				<tr>\r\n					<td>*Nachname</td>\r\n					<td><input type="text" name="nachname" id="nachname" onblur="check(\\''nachname\\'')" /></td>\r\n					<td><div id="nachname_errmsg"></div></td>\r\n				</tr>\r\n				<tr>\r\n					<td>*E-Mail Adresse</td>\r\n					<td><input type="text" name="email" id="email" onblur="check(\\''email\\'')" /></td>\r\n					<td><div id="email_errmsg"></div></td>\r\n				</tr>\r\n				<tr>\r\n					<td>Wohnort</td>\r\n					<td><input type="text" name="ort" id="ort" /></td>\r\n					<td></td>\r\n				</tr>\r\n				<tr>\r\n					<td>Telefonnummer</td>\r\n					<td><input type="text" name="telnr" id="telnr" /></td>\r\n					<td></td>\r\n				</tr>\r\n				<tr>\r\n					<td>MSN</td>\r\n					<td><input type="text" name="msn" id="msn" /></td>\r\n					<td></td>\r\n				</tr>\r\n				<tr>\r\n					<td>ICQ</td>\r\n					<td><input type="text" name="icq" id="icq" /></td>\r\n					<td></td>\r\n				</tr>\r\n				<tr>\r\n					<td>Skype</td>\r\n					<td><input type="text" name="skype" id="skype" /></td>\r\n					<td></td>\r\n				</tr>\r\n				<tr>\r\n					<td>Hobbys</td>\r\n					<td>\r\n						<select name="hobbys" id="hobbys" size="3" multiple="multiple">\r\n							<option value="Feuerwehr">Feuerwehr</option>\r\n							<option value="Schwimmen">Schwimmen</option>\r\n							<option value="Schi fahren">Schi fahren</option>\r\n							<option value="Computer spielen">Computer spielen</option>\r\n							<option value="Rad fahren">Rad fahren</option>\r\n						</select>\r\n					</td>\r\n					<td></td>\r\n				</tr>\r\n				<tr>\r\n					<td colspan="2" align="center"><input type="button" name="absenden" id="absenden" value="Absenden" onclick="fullCheck()" /></td>\r\n				</tr>\r\n			</table>\r\n		</form>\r\n		Mit * markierte Felder m&uuml;ssen ausgef&uuml;llt werden!'';\r\n		\r\n	}\r\n?>'),
(7, 'login', '', '<!--\r\n	Copyright 2008 Philip W&ouml;lfel <philip.woelfel@frig.at>\r\n--><?php\n	//$selbst = "?site=" .$_GET[''site''];\r\n	global $selbst;\r\n	if(isset($_POST[''name'']) && isset($_POST[''passwd''])){\r\n		$users = mysql_query("select id, name, passwort from users where name = ''" .$_POST[''name''] ."'' and unlocked = 1");\r\n		if(mysql_num_rows($users)>0){\r\n			$row = mysql_fetch_array($users);\r\n			if($row[''passwort''] == hash($config[''hash_algo''], $_POST[''passwd''])){\r\n				$_SESSION[''userid''] = $row[''id''];\r\n				$_SESSION[''userpsw''] = $row[''passwort''];\r\n				$_SESSION[''username''] = $row[''name''];\r\n			\r\n				echo ''<a href="index.php">Hier</a> gelangen sie zur Startseite.'';\r\n				//http_redirect("index.php");\r\n				header("Location: index.php");\r\n				\r\n			}\r\n			else{\r\n				echo ''Sie haben ein falsches Passwort eingegeben.<br /><a href="index.php'' .$selbst .''">Hier</a> k&ouml;nnen sie erneut versuchen sich einzuloggen.'';\r\n			}\r\n		}\r\n		else{\r\n			echo ''Der Benutzername existiert nicht oder ihr Account wurde noch nicht freigeschalten!<br /><a href="index.php'' .$selbst .''">Hier</a> k&ouml;nnen sie erneut versuchen sich einzuloggen'';\r\n		}\r\n	}\r\n	else{\r\n		echo ''Hier k&ouml;nnen sie sich einloggen:\r\n					<form method="post" action="">\r\n						Username: <input type="text" name="name" /><br />\r\n						Passwort: <input type="password" name="passwd" /><br />\r\n						<input type="submit" value="Login" />\r\n					</form>'';\r\n	}\r\n?>\r\n'),
(8, 'new_termin', '', '<!--\r\n	Copyright 2008 Philip W&ouml;lfel <philip.woelfel@frig.at>\r\n-->\r\n<?php\r\n$monate[1]=''J&auml;nner'';\r\n$monate[2]=''Februar'';\r\n$monate[3]=''M&auml;rz'';\r\n$monate[4]=''April'';\r\n$monate[5]=''Mai'';\r\n$monate[6]=''Juni'';\r\n$monate[7]=''Juli'';\r\n$monate[8]=''August'';\r\n$monate[9]=''September'';\r\n$monate[10]=''Oktober'';\r\n$monate[11]=''November'';\r\n$monate[12]=''Dezember'';\r\n$jahr = date("Y");\n//$selbst = "?site=" .$_GET[''site''];\r\nglobal $selbst;\r\necho ''<form method="post" action="'' .$selbst .''">\r\nJahr: <select name="jahr">\r\n		<option value="'' .$jahr .''">'' .$jahr .''</option>\r\n		<option value="'' .($jahr+1) .''">'' .($jahr+1) .''</option>\r\n		<option value="'' .($jahr+2) .''">'' .($jahr+2) .''</option>\r\n		<option value="'' .($jahr+3) .''">'' .($jahr+3) .''</option>\r\n	</select><br />\r\nMonat: <select name="monat">\r\n'';\r\nfor($i=1;$i<=12;$i++){\r\n	echo ''<option value="'' .$i .''">'' .$monate[$i] .''</option>\r\n	'';\r\n}\r\necho ''</select>\r\n			<br />\r\n			Tag: <select name="tag">\r\n			'';\r\nfor($j=1;$j<=31;$j++){\r\n	echo ''<option value="'' .$j .''">'' .$j .''</option>\r\n	'';\r\n}\r\necho ''</select>\r\n<br />\r\nTermin: <input type="text" name="termin" />\r\n<br />\r\n<input type="submit" value="Termin speichern" />\r\n</form>'';\r\n\r\nif(isset($_POST[''monat'']) && isset($_POST[''tag'']) && isset($_POST[''termin'']) && isset($_POST[''jahr''])){\r\n	$monat = $_POST[''monat''];\r\n	$tag = $_POST[''tag''];\r\n	$termin = $_POST[''termin''];\r\n	$jahr = $_POST[''jahr''];\r\n	mysql_query("insert into termine (`datum`,`kurztext`,`langtext`) values (''" .$jahr ."-" .$monat ."-" .$tag ."'', ''" .$termin ."'', ''lang'')");\r\n}\r\n?>'),
(21, 'klassen', '', '<?php\r\n	global $selbst;\r\n	echo "<table>";\r\n	$users_qry = mysql_query("select id, name, vorname, nachname, email, ort, telnr, msn, icq, skype, pic from users order by name");\r\n	while($user = mysql_fetch_array($users_qry)){\r\n		if(file_exists(''images/avatars/'' .$user[''id''] .$user[''pic''])){\r\n			$img = ''images/avatars/'' .$user[''id''] .$user[''pic''];\r\n		}\r\n		else{\r\n			$img = ''images/avatars/default.jpg'';\r\n		}\r\n		echo "<tr>";\r\n		echo ''<td><img src="'' .$img .''" alt="Avatar von '' .$user[''name''] .''" /></td>'';\r\n		echo ''<td>'' .$user[''vorname''] .'' '' .$user[''nachname''] .''</td>'';\r\n		echo ''<td><a href="'' .$selbst .''&id='' .$user[''id''] .''">mehr Infos...</a></td>'';\r\n		echo "</tr>";\r\n	}\r\n	echo "</table>";\r\n?>\r\n'),
(22, 'usercp', '', '<?php\r\necho ''Benutzerkontrollzentrum'';\r\n?>'),
(23, 'admincp', '', 'Zur Content Administration gehts <a href="admin/index.php">hier</a>.<br />\r\nF&uuml;r andere administrative T&auml;tigkeiten bitte einen Unterpunkt ausw&auml;hlen.'),
(24, 'profil_edit', '', 'Profil bearbeiten'),
(25, 'avatar_upload', '', '<?php\necho ''<form method="post" enctype="multipart/form-data" action="">\n		<input type="file" name="datei" />\n		<input type="submit" value="upload" />\n	  </form>'';\n$types = array(	"image/jpeg", //jpeg\n				"image/png", //png\n				"image/gif", //gif\n				"image/bmp", //bmp\n				);\nif(isset($_FILES[''datei''])){\n	//echo $_FILES[''datei''][''type''];\n	$allowedtype = false;\n	for($i=0;$i<sizeof($types);$i++){\n		if($types[$i]==$_FILES[''datei''][''type'']){\n			$allowedtype = true;\n			break;\n		}\n	}\n	//echo "<br />all: " .$allowedtype;\n	if($allowedtype && isset($_FILES[''datei''][''tmp_name'']) && $_FILES[''datei''][''size'']<7000000){\n		$filetmp = $_FILES[''datei''][''name''];\n		$suffix = substr($filetmp, -(strlen($filetmp)-strrpos($filetmp, ".")), (strlen($filetmp)-strrpos($filetmp, ".")) );\n		if(!move_uploaded_file($_FILES[''datei''][''tmp_name''], "images/avatars/" .$_SESSION[''userid''] .$suffix)){\n			echo "Fehler beim uploaden!";\n		}\n		else{\n			mysql_query("update users set pic=''$suffix'' where id=" .$_SESSION[''userid'']) or die("Fehler beim speichern!");\n			echo "Datei upgeloadet!";\n		}\n	\n	}\n	else{\n		echo "Dateityp ist nicht erlaubt oder datei ist zu gro&szlig;!";\n	}\n}\n?>'),
(26, 'nachrichten', '', 'Nachrichten versenden'),
(27, 'friends', '', 'Freunde verwalten'),
(28, 'news_admin', '', '<?php\n	global $selbst;\n	require("admin/admin_funcs.php");\n	\n	echo ''<h1>News Administration</h1>\n			<a href="'' .$selbst .''&action=newNews">neue News</a><br />\n			<a href="'' .$selbst .''&action=editNews">News bearbeiten</a><br />\n			<a href="'' .$selbst .''&action=delNews">News l&ouml;schen</a><br /><hr />'';\n	\n	if(isset($_GET[''action''])){\n		$action = $_GET[''action''];\n		if(isset($_SESSION[''userid''], $_SESSION[''username''])){\n			$admin = new AdminFunctions("", "");\n			if($admin->testUser()){\n				switch($action){\n					case "newNews": $admin->action("newNews"); break;\n					case "editNews": $admin->action("editNews"); break;\n					case "delNews": $admin->action("delNews"); break;\n					default: break;\n				}\n			}\n		}\n	}\n	\n	\n?>'),
(29, 'user_admin', '', 'User Verwaltung'),
(30, 'klassen_admin', '', 'Klassen verwalten'),
(31, 'send_email', '', 'E-Mail versenden');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `nav`
--

CREATE TABLE IF NOT EXISTS `nav` (
  `id` int(5) NOT NULL auto_increment,
  `titel` varchar(50) NOT NULL,
  `site` varchar(50) NOT NULL,
  `nav` int(5) NOT NULL,
  `pos` int(5) NOT NULL,
  `klasse` varchar(50) NOT NULL,
  `recht` int(5) NOT NULL,
  `extern` tinyint(1) NOT NULL,
  `no_login` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Daten für Tabelle `nav`
--

INSERT INTO `nav` (`id`, `titel`, `site`, `nav`, `pos`, `klasse`, `recht`, `extern`, `no_login`) VALUES
(1, 'News', 'news', 1, 1, 'navi', 0, 0, 0),
(23, 'Benutzerkontrollzentrum', 'usercp', 2, 1, 'navi', 50, 0, 0),
(25, 'Profil bearbeiten', 'profil_edit', 2, 2, 'navi_sub', 50, 0, 0),
(5, 'Registrierung', 'register', 1, 5, 'navi', 0, 0, 1),
(27, 'Nachricht senden', 'nachrichten', 2, 4, 'navi_sub', 50, 0, 0),
(24, 'Admininstration', 'admincp', 3, 1, 'navi', 100, 0, 0),
(26, 'Avatarbild uploaden', 'avatar_upload', 2, 3, 'navi_sub', 50, 0, 0),
(6, 'Login', 'login', 1, 4, 'navi', 0, 0, 1),
(28, 'Freunde verwalten', 'friends', 2, 5, 'navi_sub', 50, 0, 0),
(21, 'Forum', 'forum/index.php', 1, 2, 'navi', 0, 1, 0),
(22, 'User', 'klassen', 1, 3, 'navi', 0, 0, 0),
(29, 'News', 'news_admin', 3, 2, 'navi_sub', 100, 0, 0),
(30, 'User', 'user_admin', 3, 3, 'navi_sub', 100, 0, 0),
(31, 'Klassen', 'klassen_admin', 3, 4, 'navi_sub', 100, 0, 0),
(32, 'E-Mail versenden', 'send_email', 3, 5, 'navi_sub', 100, 0, 0),
(41, 'Kalendar', 'kalender', 1, 6, 'navi', 0, 0, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `navgroups`
--

CREATE TABLE IF NOT EXISTS `navgroups` (
  `id` int(5) NOT NULL auto_increment,
  `titel` varchar(50) NOT NULL,
  `pos` int(5) NOT NULL,
  `recht` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Daten für Tabelle `navgroups`
--

INSERT INTO `navgroups` (`id`, `titel`, `pos`, `recht`) VALUES
(1, 'Home', 1, 0),
(2, 'Benutzer', 2, 50),
(3, 'Admin', 3, 100);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(5) NOT NULL auto_increment,
  `titel` varchar(30) NOT NULL,
  `datum` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `text` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Daten für Tabelle `news`
--

INSERT INTO `news` (`id`, `titel`, `datum`, `text`) VALUES
(2, 'Hallo Welt', '2009-04-21 17:05:55', 'Wie gehts dir denn?<br />\r\nTest<br />\r\nblablubbb'),
(3, 'blablablubbbb', '2009-04-21 17:06:00', '<p>Hello World!<br /> <br /> lasjhdf<br /> adfhasdfhasd<br /> fa<br /> sdf<br /> as</p>\r\n<p><br />lqhtqowhtfa</p>\r\n<ul>\r\n<li>ljahg</li>\r\n<li>gealh</li>\r\n<li>ihegourgh</li>\r\n</ul>\r\n<h2>khfjf</h2>\r\n<p>&nbsp;</p>'),
(4, 'Testing', '2009-05-27 08:57:29', 'Datum??<br />\r\nhallo wie gehts<br />\r\ngasdasg<br />\r\na+gheiahgae<br />\r\nasdg<br />\r\na<br />\r\nsdgajsrlighwr<br />\r\ngasdf<br />\r\nagljhawogrj');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `news_comments`
--

CREATE TABLE IF NOT EXISTS `news_comments` (
  `id` int(10) NOT NULL auto_increment,
  `newsid` int(10) NOT NULL,
  `userid` int(10) NOT NULL,
  `datum` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `comment` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Daten für Tabelle `news_comments`
--

INSERT INTO `news_comments` (`id`, `newsid`, `userid`, `datum`, `comment`) VALUES
(1, 1, 1, '2008-11-14 17:42:36', 'Hallo das ist der erste Comment'),
(2, 1, 1, '2008-11-14 17:44:13', 'Hallo das ist der zweite Comment'),
(7, 3, 1, '2009-03-06 17:51:22', 'Wie gehts?'),
(5, 2, 1, '2008-11-15 16:18:30', 'Hehe :D'),
(6, 2, 1, '2008-12-05 11:26:31', 'woot'),
(8, 3, 1, '2009-03-18 11:42:14', ':D'),
(9, 4, 1, '2009-05-07 23:00:24', 'ichduersieesbausparen');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rechte`
--

CREATE TABLE IF NOT EXISTS `rechte` (
  `id` int(5) NOT NULL auto_increment,
  `titel` varchar(50) NOT NULL,
  `recht` int(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Daten für Tabelle `rechte`
--

INSERT INTO `rechte` (`id`, `titel`, `recht`) VALUES
(2, 'keine', 0),
(3, 'Benutzer', 50),
(4, 'Admin', 100);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `shoutbox`
--

CREATE TABLE IF NOT EXISTS `shoutbox` (
  `id` int(5) NOT NULL auto_increment,
  `Name` varchar(30) default NULL,
  `Nachricht` varchar(100) default NULL,
  `created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `shoutbox`
--

INSERT INTO `shoutbox` (`id`, `Name`, `Nachricht`, `created`) VALUES
(1, 'Philip', 'Es funktioniert :D :P :) :( ;( ;| ;D ', '2008-08-18 15:45:54');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `termine`
--

CREATE TABLE IF NOT EXISTS `termine` (
  `id` int(5) NOT NULL auto_increment,
  `datum` date NOT NULL,
  `kurztext` varchar(200) NOT NULL,
  `langtext` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Daten für Tabelle `termine`
--

INSERT INTO `termine` (`id`, `datum`, `kurztext`, `langtext`) VALUES
(4, '2009-01-01', '1. J&auml;nner', '<p>Das ist der <strong>1.</strong> J&auml;nner</p>\r\n<ol>\r\n<li>ja</li>\r\n<li>nein</li>\r\n<li>weis nicht</li>\r\n<li>hab angst</li>\r\n<li>will nach hause</li>\r\n</ol>');
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `passwort` varchar(50) NOT NULL,
  `datum` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `rechte` int(2) NOT NULL,
  `unlocked` tinyint(1) NOT NULL default '0',
  `vorname` varchar(30) NOT NULL,
  `nachname` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ort` varchar(100) default NULL,
  `telnr` int(15) default NULL,
  `msn` varchar(50) default NULL,
  `icq` int(10) default NULL,
  `skype` varchar(50) default NULL,
  `reg_hash` varchar(128) NOT NULL,
  `pic` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

--
-- Daten für Tabelle `users`
--

INSERT INTO `users` (`id`, `name`, `passwort`, `datum`, `rechte`, `unlocked`, `vorname`, `nachname`, `email`, `ort`, `telnr`, `msn`, `icq`, `skype`, `reg_hash`, `pic`) VALUES
(4, 'User', '1c3add61d9d4cd4ff50268900e926055c27390bf', '1992-06-10 21:57:09', 50, 1, 'Normaler', 'User', 'user@user.at', '', 0, '', 0, '', '', ''),
(5, 'Admin', '289bed0325c26d04da9ba999fb6c4defd8ab76f6', '2009-05-06 21:57:52', 100, 1, 'Admin', 'User', 'admin@user.at', '', 0, '', 0, '', '', '');