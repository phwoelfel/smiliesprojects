import java.util.*;


class Semaphora {
	int zaehler;
	ArrayList<Philosoph> user;
	
	
	public Semaphora(int start){
		zaehler = start;
		user = new ArrayList<Philosoph>();
	}
	
	
}
